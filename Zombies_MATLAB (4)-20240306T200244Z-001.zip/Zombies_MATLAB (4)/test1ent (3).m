% Initialize test parameters
N_test = 100; M_test = 100; % Smaller grid for testing
testGrid = zeros(N_test, M_test); % Initial test grid
% Define a small number of entities for a clear test scenario
numWizards = 2; numDragons = 1;
numArchers=3;% Example entity counts

% Prepare shuffled positions for the test grid
allPositions_test = combvec(1:N_test, 1:M_test)';
shuffledPositions_test = allPositions_test(randperm(numel(testGrid)), :);

% Place entities using the placeEntity function
[testGrid, ~] = placeEntity(testGrid, 1, numWizards, shuffledPositions_test); % Place Wizards
[testGrid, shuffledPositions_test] = placeEntity(testGrid, 2, numDragons, shuffledPositions_test); % Place Dragons
[testGrid, ~] = placeEntity(testGrid, 3, numArchers, shuffledPositions_test);
% Visualize the resulting grid
imagesc(testGrid);
colorbar; % Helps differentiate entities visually
title('Test Placement of Entities');
