function [X, updatedShuffledPositions] = placeEntity(X, entity, count, shuffledPositions)
    % Select the first 'count' positions from the shuffled list
    selectedPositions = shuffledPositions(1:count, :);
    
    % Place the entity at each selected position
    for i = 1:size(selectedPositions, 1)
        r = selectedPositions(i, 1);
        c = selectedPositions(i, 2);
        X(r, c, 1) = entity; % Assuming the initial state is stored in the first "page" of X
    end
    
    % Return the grid and the remaining shuffled positions
    updatedShuffledPositions = shuffledPositions(count + 1:end, :);
end


% Calculate the number of entities based on percentages
% (use previously shown calculation method here)

% Place each entity type
%[X, shuffledPositions] = placeEntity(X, 1, nWizards, shuffledPositions); % Wizards
%[X, shuffledPositions] = placeEntity(X, 2, nDragons, shuffledPositions); % Dragons
%[X, shuffledPositions] = placeEntity(X, 3, nGiants, shuffledPositions); % Giants
%[X, shuffledPositions] = placeEntity(X, -1, nInfraTs, shuffledPositions); % Infra Towers
%[X, shuffledPositions] = placeEntity(X, -2, nMorters, shuffledPositions); % Mortars
%[X, shuffledPositions] = placeEntity(X, -3, nArchers, shuffledPositions); % Archers

