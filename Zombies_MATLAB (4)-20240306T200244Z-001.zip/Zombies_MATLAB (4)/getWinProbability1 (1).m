function prob = getWinProbability1(entity, target, pWin)
    % Assuming pWin is a structure with fields like 'wizardVsDragon'
    matchKey = sprintf('%dVs%d', entity, target);
    if isfield(pWin, matchKey)
        prob = pWin.(matchKey);
    else
        prob = 0.5;  % Default probability if no specific rule exists
    end
end
