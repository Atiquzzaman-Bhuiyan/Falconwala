% Simulation parameters
N = 20; M = 20;  % Grid size
numSimulations = 1000; 
T=1;% Number of simulation runs

% Entity initialization probabilities
pWizard = 0.02; pDragons = 0.01; pGiant = 0.01;
pHealer = 0.02; pInfraT = 0.1; pMorter = 0.1; pArchers = 0.01;

% Storage for grid initializations
initialStates = strings(numSimulations, 1);

for sim = 1:numSimulations
    % Initialize the grid for this simulation
    X = zeros(N, M);

    % Generate shuffled positions anew for each simulation
    allPositions = combvec(1:N, 1:M)';
    shuffledPositions = allPositions(randperm(size(allPositions, 1)), :);

    % Place each entity type for the current simulation
    % Assuming placeEntity function correctly places entities and doesn't require X as input
    X = placeEntity(N, M, nWizards, 1, shuffledPositions);
    X = placeEntity(N, M, nDragons, 2, shuffledPositions);
    X = placeEntity(N, M, nGiants, 3, shuffledPositions);
    X = placeEntity(N, M, nInfraTs, -1, shuffledPositions);
    X = placeEntity(N, M, nMorters, -2, shuffledPositions);
    X = placeEntity(N, M, nArchers, -3, shuffledPositions);

    % Convert the initial grid state to a string for comparison
    initialStateString = mat2str(X);

    % Store the string representation
    initialStates(sim) = initialStateString;
end

[uniqueStates, ~, idx] = unique(initialStates);
frequencyCounts = accumarray(idx, 1);

% Display the results
for i = 1:length(uniqueStates)
    fprintf('Initialization %d occurred %d times.\n', i, frequencyCounts(i));
end
