function [Xnew] = move(i, j, k, l, X, pWin)
% Xnew is the updated grid after the move/interaction
% (i,j) are the coordinates of the moving entity
% (k,l) are the coordinates of the target cell
% X is the current state of the grid
% pWin is a structure containing the probabilities of winning for different matchups

Xnew = X;  % Copy the current state to a new grid

entity = X(i, j);  % Entity attempting to move or interact
target = X(k, l);  % Entity or space at the target location

% Check if the cell is occupied by an ally, an enemy, or is empty
if entity * target > 0 || target == 0
    % Allies or empty space: simply move if empty
    if target == 0
        Xnew(i, j) = 0;  % Vacate current cell
        Xnew(k, l) = entity;  % Occupy new cell
    end
    % If target is an ally, no action is taken
else
    % Encounter with an enemy
    % Determine the outcome based on the specific probabilities or rules
    outcome = rand() < getWinProbability(entity, target, pWin);
    if outcome
        % Entity wins and takes over the target cell
        Xnew(i, j) = 0;  % Vacate current cell
        Xnew(k, l) = entity;  % Replace the enemy
    else
        % Entity loses and is removed from the grid (or converted, based on your rules)
        Xnew(i, j) = 0;  % Entity is removed or converted
    end
end

end

function prob = getWinProbability(entity, target, pWin)
    % This function returns the winning probability based on the entity and target.
    % pWin is a structure that should contain the winning probabilities.
    % Example: pWin.wizardVsInfraT = 0.7;
    
    % Define a default probability in case a specific matchup isn't defined
    defaultProb = 0.5;  
    prob = defaultProb;  % Default probability
    
    % Example of determining the probability
    if entity == 1 && target == -1  % Example: Wizard vs. Infra Tower
        probKey = 'wizardVsInfraT';
        if isfield(pWin, probKey)
            prob = pWin.(probKey);
        end
    end


    if entity == 2 && target == -2  % Example: Wizard vs. Infra Tower
        probKey = 'Dragpnarcher';
        if isfield(pWin, probKey)
            prob = pWin.(probKey);
        end
    end

     if entity ==3 && target == -3  % Example: Wizard vs. Infra Tower
        probKey = 'Giantmorter';
        if isfield(pWin, probKey)
            prob = pWin.(probKey);
        end
     end
    end
    % Add more conditions for other specific matchups
