function [Nei] = Neighbourhod(n,m,N,M)
% Determines the neighborhood of cell (n,m)
% Inputs:
   % N:  number of rows in matrix X
   % M:  number of columns in matrix X

if n == 1
    if m == 1
        Nei = [n m; n+1 m; n m+1; n+1 m+1];
    elseif m == M
        Nei = [n m; n+1 m; n m-1; n+1 m-1];
    else
        Nei = [n m; n+1 m; n m-1; n+1 m-1; n m+1; n+1 m+1];
    end
elseif n == N
    if m == 1
        Nei = [n m; n-1 m; n m+1; n-1 m+1];
    elseif m == M
        Nei = [n m; n-1 m; n m-1; n-1 m-1];
    else
        Nei = [n m; n-1 m; n m-1; n-1 m-1; n m+1; n-1 m+1];
    end
else
    if m == 1
        Nei = [n m; n-1 m; n+1 m; n m+1; n-1 m+1; n+1 m+1];
    elseif m == M
        Nei = [n m; n-1 m; n+1 m; n m-1; n-1 m-1; n+1 m-1];
    else
        Nei = [n m; n-1 m; n+1 m; n m-1; n-1 m-1; n+1 m-1; n m+1; n-1 m+1; n+1 m+1];
    end
end

end