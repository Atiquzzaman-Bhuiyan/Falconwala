function [cell] = pickCell(N,M,X)
%Picks a random cell to simulate, loops until a cell that has -1 or 1 is
%found

n = randi(N);
m = randi(M);
while X(n,m) == 0
    n = randi(N);
    m = randi(M);
end
cell = [n m];

end

%swlwcts nonempty cell