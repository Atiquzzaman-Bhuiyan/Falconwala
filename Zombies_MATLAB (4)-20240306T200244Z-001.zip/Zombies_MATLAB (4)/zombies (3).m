N = 100; % number of rows
M = 100; % number of columns
T = 100000; % number of time steps to simulate
phz = 0.9; % probability that a human kills a zombie in a fight
phh = 0.1; % probability that a human targets and kills another human

X = zeros(N,M,T);

% INITIALIZE STATE MATRIX
pLiving = 0.2;
pZombies = 0.05;
X(:,:,1) = binornd(1,pLiving,N,M) + (-1 .* binornd(1,pZombies,N,M));

for t=1:T
    % UPDATE STATE MATRIX
    % randomly select a cell
    c = pickCell(N,M,X(:,:,t));

    % simulate target cell
    tc = TargetCell(c(1,1),c(1,2),X(:,:,t));

    % update cell system state
    X(:,:,t+1) = move(c(1,1),c(1,2),tc(1,1),tc(1,2),X(:,:,t),phz,phh);
end

%Nh1 = sum(X(:,:,1) == 1,'all'); %number of humans at time step 1