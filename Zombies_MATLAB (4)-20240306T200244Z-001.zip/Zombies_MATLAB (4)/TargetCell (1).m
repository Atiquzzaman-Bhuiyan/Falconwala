function [T] = TargetCell(i,j,X)
%Returns the target cell for cell (i,j)
%Inputs:
    % X: th current state of the system

Nei = Neighbourhod(i,j,size(X,1),size(X,2));
szNei = size(Nei,1);
Scores = zeros(szNei,1);
for r = 1:szNei
    Scores(r,1) = score(X(i,j), X( Nei(r,1),Nei(r,2) ) );
end

Z = sum(sum(Scores));

Pij = (1/Z) .* Scores; 

% simulate
u = rand;

p0 = 0;
t = 1;
for n = 1:szNei
    if u < p0+Pij(n,1)
        t = n;
        break;
    else
        p0 = p0 + Pij(n,1);
    end
end

T = Nei(t,:);
end