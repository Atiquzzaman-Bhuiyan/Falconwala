% Filename: interact.m

function [outcome] = interacr23test(entity1, entity2, powers)
    % Determine if entities are from different groups (negative vs positive identifiers)
   
    if entity1 * entity2 < 0
        % Assign power levels based on entity type
        power1 = getPower(abs(entity1), powers);
        power2 = getPower(abs(entity2), powers);
        
        % Determine outcome based on power levels
        if power1 > power2
            outcome = entity1; % Entity 1 wins
        elseif power2 > power1
            outcome = entity2; % Entity 2 wins
        elseif power1 == power2;
            outcome = entity1; % Draw, both entities are removed or no clear outcome
        end
    else
        outcome = entity2; % No interaction, entities from the same group or no combat scenario
    end
   
end
    
function power = getPower(entity, powers)
    % Map entity numbers to their powers
    switch entity
        case 1 % Wizard
            power = powers.wizard;
        case 2 % Dragon
            power = powers.dragon;
        case 3 % Giant
            power = powers.giant;
        case -3 % Archer
            power = powers.archer;
        case -2 % Mortar
            power = powers.mortar;
        case -1 % Infra Tower
            power = powers.infraTower;
        otherwise
            power = 0; % Undefined entity
    end
end
