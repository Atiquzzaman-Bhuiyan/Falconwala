function [k, l] = chooseRandomAdjacentCell(i, j, N, M)
    directions = [-1, 0; 1, 0; 0, -1; 0, 1]; % Up, Down, Left, Right
    idx = randi(size(directions, 1)); % Choose a random direction
    k = max(min(i + directions(idx, 1), N), 1); % Ensure within bounds
    l = max(min(j + directions(idx, 2), M), 1);
end
