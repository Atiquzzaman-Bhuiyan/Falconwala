% Example usage in your main simulation script

% Initialize the powers structure
powers = powersConfig();

% Example interaction between a wizard (1) and an archer (-3)
outcome = interact(1, -3, powers);

% Process the outcome...
