% Simulation parameters
N = 100; % Grid size
M = 100;
T = 100; % Number of time steps

% Initialize the grid
X = zeros(N, M);
% ... Code to initialize your grid with entities ...

% Prepare the figure for plotting
figure;
colormap(jet); % Choose a colormap that suits your preference
caxis([-3 3]); % Assuming -3 to 3 represents the range of entities

for t = 1:T
    % Update the grid based on your simulation logic
    % This is where you would call your simulation functions to update X
    % X = updateSimulation(X);
    
    % Visualize the current state of the grid
    imagesc(X);
    colorbar; % Optional: Display a colorbar indicating entity types
    title(['Time Step: ', num2_tstr(t)]);
    drawnow; % This function updates the figure window

    % Pause the loop to visualize changes; adjust the pause duration as needed
    pause(0.1); % Pauses for 0.1 seconds
end
