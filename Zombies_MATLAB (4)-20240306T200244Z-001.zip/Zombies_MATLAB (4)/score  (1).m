function [pi] = score(Xij,Xkl)
%returns a score associated with (n,m) -> (k,l)

if Xij == 0
    pi = 0;
elseif Xij == -1
    if Xkl == 0
        pi = 1;
    elseif Xkl == -1
        pi = 0;
    else
        pi = 2;
    end
else
    if Xkl == 0
        pi = 2;
    elseif Xkl == -1
        pi = 0;
    else
        pi = 1;
    end
end
end