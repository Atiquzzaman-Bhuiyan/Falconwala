function pWin = interactionProbabilities()
    pWin = struct('wizardVsInfraT', 0.5, 'giantVsArcher', 0.4, 'wizardVsmorter',0.7, 'wizardVsArcher',0.3,...
                   'DragonVsInfra',0.5,'DragonVsmorter', 0.6,'DragonVsArcher',0.3,'giantVsWizard',0.6, 'giantVsMorter',0.5); % Example probabilities
end