% Assuming powers structure is defined as in your interact function
powers = struct('wizard', 2, 'dragon', 3, 'giant', 2, ...
                'archer', 1, 'mortar', 2, 'infraTower', 3);

% Test Case 1: Wizard (1) vs. Archer (-3), expecting Wizard to win
outcome = interact(1, -3, powers);
assert(outcome == 1, 'Test Case 1 Failed: Wizard should win against Archer.');

% Test Case 2: Dragon (2) vs. Infra Tower (-1), expecting Infra Tower to win
outcome = interact(2, -1, powers);
assert(outcome == -1, 'Test Case 2 Failed: Infra Tower should win against Dragon.');

% Test Case 3: Giant (3) vs. Mortar (-2), expecting a draw or no effect
outcome = interact(3, -2, powers);
assert(outcome == 0, 'Test Case 3 Failed: Giant vs. Mortar should result in a draw or no effect.');

% Test Case 4: Entity from the same group (e.g., Wizard vs. Giant), expecting no interaction
outcome = interact(1, 3, powers);
assert(outcome == 0, 'Test Case 4 Failed: Entities from the same group should not interact.');

% Add more test cases as necessary to cover all interaction rules and entity pairs
