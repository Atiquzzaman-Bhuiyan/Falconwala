function [outcome] = interact(entity1, entity2)
% Simplified interaction logic based on entity power

% Define power levels
powerLevels = [1, 2, 3; % Wizard, Dragon, Giant
               -3, -2, -1]; % Archer, Mortar, Infra Tower

if entity1 * entity2 < 0 % If entities are from different groups
    power1 = powerLevels(abs(entity1));
    power2 = powerLevels(abs(entity2));
    
    if power1 > power2
        outcome = entity1; % Entity 1 wins
    elseif power2 > power1
        outcome = entity2; % Entity 2 wins
    else
        outcome = 0; % Draw, both entities are removed
    end
else
    outcome = entity1; % No interaction, entities from the same group
end
end
