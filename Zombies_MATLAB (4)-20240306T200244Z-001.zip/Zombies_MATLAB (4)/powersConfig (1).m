% Filename: powersConfig.m


function powers = powersConfig()
    powers = struct('wizard', 2, 'dragon', 3, 'giant', 2, ...
                    'archer', 1, 'mortar', 2, 'infraTower', 3);
end


