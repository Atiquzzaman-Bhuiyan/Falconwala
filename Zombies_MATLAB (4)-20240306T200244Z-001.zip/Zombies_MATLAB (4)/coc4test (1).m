N = 10; M = 10; T = 10; % Reduced grid size and time steps for debugging
X = zeros(N, M, T);
% Example: Just work with one entity type to simplify
pEntity = 0.1; % Probability for this entity type
entityType = 1; % Arbitrary entity type for testing

% Directly assign entities based on probability for the first time step
for i = 1:N
    for j = 1:M
        if rand() <= pEntity
            X(i, j, 1) = entityType;
        end
    end
end

% Proceed with simulation assuming static entities (no moves) to simplify
entityCounts = zeros(T, 1); % Tracking count for just this entity type
for t = 1:T
    entityCounts(t) = sum(X(:,:,t) == entityType, 'all');
end
plot(1:T, entityCounts, '-o', 'DisplayName', 'Entity Count');
xlabel('Time Step');
ylabel('Count');
title('Entity Count Over Time');
legend show;
