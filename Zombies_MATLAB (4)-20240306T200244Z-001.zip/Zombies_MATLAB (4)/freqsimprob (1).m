% Simulation parameters
N = 10; M = 10;  % Grid size
numSimulations = 10000;  % Number of simulation runs

% Entity initialization probabilities
pWizard = 0.02; pDragons = 0.01; pGiant = 0.01;
pHealer = 0.02; pInfraT = 0.1; pMorter = 0.1; pArchers = 0.01;

for sim = 1:numSimulations
    % Initialize the grid for this simulation
    X = zeros(N, M);
    
    % Randomly place each entity type
    X = X + (rand(N, M) < pWizard) * 1;
    X = X + (rand(N, M) < pDragons) * 2;
    % Repeat for other entities...
    
    % Convert the grid to a string for comparison (or another comparable format)
    initialStateString = mat2str(X(:,:,1));
    
    % Store the string representation
    initialStates(sim) = initialStateString;
end

    % Convert the grid to a string for comparison (or another comparable format)
    initialStateString = mat2str(X(:,:,1));
    
    % Store the string representation
    initialStates(sim) = initialStateString;


[uniqueStates, ~, idx] = unique(initialStates);
frequencyCounts = accumarray(idx, 1);

% Display the results
for i = 1:length(uniqueStates)
    fprintf('Initialization %d occurred %d times.\n', i, frequencyCounts(i));
end


