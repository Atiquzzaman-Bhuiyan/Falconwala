%powers = struct('wizard', 2, 'dragon', 3, 'giant', 2, 'archer', 1, 'mortar', 2, 'infraTower', 3);
powers = powersConfig();

assert(interact(1,-3, powers) == 1, 'Wizard should win against Archer.');
assert(interact(-1,2, powers) == -1, 'Infra Tower should win against Dragon.');
assert(interact(1, 3, powers) == 0, 'Same group entities should not interact.');
assert(interact(2, 3, powers) == 0, 'Same group entities should not interact.');