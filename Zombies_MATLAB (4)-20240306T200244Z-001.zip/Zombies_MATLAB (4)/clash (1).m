N = 100; % number of rows
M = 100; % number of columns
T = 100000; % number of time steps to simulate
%phz = 0.9; % probability that a human kills a zombie in a fight
%phh = 0.1; % probability that a human targets and kills another human

X = zeros(N,M,T);

% INITIALIZE STATE MATRIX
pWizard = 0.2;%1
pDragons= .01,%2
pGiant= 0.01;%3
pHealer=0.02;%0
pInfraT = .001;%-1
pMorter = 0.001;%-2
pArchers = .01;%-3



% Initialize the grid
X = zeros(N, M);

% Place entities randomly (simplified example, actual implementation would ensure unique positions for fixed entities and balance numbers)
% Here, we're just seeding the grid with a simple method, real implementation may require more sophisticated placement logic to ensure fairness and balance

% Group 1: Wizard (1), Dragon (2), Giant (3)
X(randi([1 N], 10, 1), randi([1 M], 10, 1)) = 1; % Wizards
X(randi([1 N], 10, 1), randi([1 M], 10, 1)) = 2; % Dragons
X(randi([1 N], 10, 1), randi([1 M], 10, 1)) = 3; % Giants

% Group 2: Infra Tower (-1), Mortar (-2), Archer (-3) with fixed positions for towers and mortars
X(randi([1 N], 5, 1), randi([1 M], 5, 1)) = -1; % Infra Towers
X(randi([1 N], 5, 1), randi([1 M], 5, 1)) = -2; % Mortars
X(randi([1 N], 10, 1), randi([1 M], 10, 1)) = -3; % Archers


X(:,:,1) = binornd(-3,pArchers,N,M) + (-2 .* binornd(1,pMorter,N,M) )+ (-1.* binornd(1,pInfraT,N,M)) +(0 .* binornd(1,pHealer,N,M)) + (1 .* binornd(1,pGiant,N,M))+ (2 .* binornd(2,pDragons,N,M)) + (3 .* binornd(1,pWizard,N,M));

for t=1:T
    % UPDATE STATE MATRIX
    % randomly select a cell
    c = pickCell(N,M,X(:,:,t));

    % simulate target cell
    tc = TargetCell(c(1,1),c(1,2),X(:,:,t));

    % update cell system state
    X(:,:,t+1) = move(c(1,1),c(1,2),tc(1,1),tc(1,2),X(:,:,t),phz,phh);
end

%Nh1 = sum(X(:,:,1) == 1,'all'); %number of humans at time step 1