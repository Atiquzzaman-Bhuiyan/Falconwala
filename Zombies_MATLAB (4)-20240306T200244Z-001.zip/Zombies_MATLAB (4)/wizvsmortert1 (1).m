N = 50; % number of rows
M = 50; % number of columns
T = 10000; % number of time steps to simulate
X = zeros(N, M, T);
% Probabilities
pWizard = 0.6; % 1
pDragons = 0.03; % 2
pGiant = 0.01; % 3
pHealer = 0.02; % 0
pInfraT = 0.02; % -1
pMorter = 0.4; % -2
pArchers = 0.1; % -3


totalCells = N*M;
nWizards = round(pWizard * totalCells);
nDragons = round(pDragons * totalCells);
nGiants = round(pGiant * totalCells);
nHealers = round(pHealer * totalCells); % Assuming you want to use healers but have assigned them a '0' value
nInfraTs = round(pInfraT * totalCells);
nMorters = round(pMorter * totalCells);
nArchers = round(pArchers * totalCells);
entityCounts = zeros(T, 3); % 7 for each entity type

allPositions = combvec(1:N, 1:M)';
shuffledPositions = allPositions(randperm(size(allPositions, 1)), :);
%Place each entity type
[X, shuffledPositions] = placeEntity(X, 1, nWizards, shuffledPositions); % Wizards
%[X, shuffledPositions] = placeEntity(X, 2, nDragons, shuffledPositions); % Dragons
%[X, shuffledPositions] = placeEntity(X, 3, nGiants, shuffledPositions); % Giants
%[X, shuffledPositions] = placeEntity(X, -1, nInfraTs, shuffledPositions); % Infra Towers
[X, shuffledPositions] = placeEntity(X, -2, nMorters, shuffledPositions); % Mortars
%[X, shuffledPositions] = placeEntity(X, -3, nArchers, shuffledPositions); % Archers

% Assuming powersConfig and interact are defined as per your setup
%powers = powersConfig(); % Load or define the powers structure
% Temporary grid to accumulate changes without immediately affecting other interactions
%Xtemp = X(:,:,t);

% Assuming powersConfig and placeEntity are already correctly used to initialize the simulation

%powers = powersConfig();  % Load the powers configuration


    % Visualization of the current state
      % Adjust pause for real-time visualization speed
% Assuming powersConfig and interactionProbabilities are defined
powers = powersConfig();
pWin = interactionProbabilities();

% Initialize the simulation grid, X, as you've done
% ...

for t = 1:T-1
    Xtemp = zeros(N, M); % Temporary grid for the next state
    
    for i = 1:N
        for j = 1:M
            % Identify the entity at the current position
            entity = X(i, j, t);
            if entity ~= 0 % Skip empty cells
                % Determine the target cell for interaction or movement
                % For simplicity, consider a random adjacent cell
                [k, l] = chooseRandomAdjacentCell(i, j, N, M);
                
                % Use the move function to simulate interaction or movement
                Xtemp = move(i, j, k, l, X(:,:,t), pWin);
            end
        end
    end
    
    % Update the state of the simulation
    X(:,:,t+1) = Xtemp;
     for entityType = [-2,0,1]
        count = sum(X(:,:,t+1) == entityType, 'all');
        entityCounts(t+1, find([ -2, 0, 1] == entityType)) = count;
    end
    
    % Visualization (optional, can slow down simulation)
    %imagesc(X(:,:,t+1)); colormap(jet); colorbar;
    %title(sprintf('Time Step: %d', t+1)); drawnow;
end

figure;
hold on;
colors = lines(7); % Get 7 distinct colors
for i = 1:3
    plot(1:T, entityCounts(:, i), 'Color', colors(i,:), 'DisplayName', sprintf('Entity %d', i-2));
end
hold off;
xlabel('Time Step');
ylabel('Number of Entities');
title('Number of Entities Over Time');
legend show;


% Loop over all cells for interactions
% Assuming powersConfig and interact are defined as per your setup
%powers = powersConfig(); % Load or define the powers structure

%figure; % For visualization setup


    
    % Apply the accumulated changes for the next time step
  


% Example visualization setup

    %imagesc(X(:,:,1)); % Check the initial setup
    %%colorbar; % To help interpret the values/colors
    %title('Initial Setup');

    


   



